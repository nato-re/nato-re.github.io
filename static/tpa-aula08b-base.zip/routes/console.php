<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment('TPA COTEMIG - Aula 08B: Integração de APIs');
})->purpose('Mensagem inspiradora didática');
