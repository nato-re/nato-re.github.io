<?php

use App\Http\Controllers\WebController;
use Illuminate\Support\Facades\Route;

Route::get('/', [WebController::class, 'index'])->name('home');
Route::get('/ibovespa', [WebController::class, 'index'])->name('ibovespa.index');
