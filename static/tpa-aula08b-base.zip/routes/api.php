<?php

use App\Http\Controllers\IbovespaController;
use Illuminate\Support\Facades\Route;

/**
 * Rotas da API da aplicação.
 *
 * Requisição 2: O navegador consome esta rota via fetch('/api/ibovespa/pos-eleicoes').
 * Por ser da mesma origem (same-origin), não sofre restrições de CORS impostas pelo navegador.
 */
Route::get('/ibovespa/pos-eleicoes', [IbovespaController::class, 'index'])->name('api.ibovespa.pos-eleicoes');
