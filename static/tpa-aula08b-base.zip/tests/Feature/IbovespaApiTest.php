<?php

namespace Tests\Feature;

use App\Services\IbovespaService;
use Tests\TestCase;

class IbovespaApiTest extends TestCase
{
    /**
     * Testa se a rota web principal (Requisição 2 - Frontend) renderiza com sucesso.
     */
    public function test_pagina_principal_renderiza_com_sucesso(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
        $response->assertSee('Séries do Ibovespa em Períodos Pós-Eleitorais');
        $response->assertSee('Requisição 1: Servidor-a-Servidor');
        $response->assertSee('Requisição 2: Cliente-ao-Servidor');
        $response->assertSee('não implica causalidade');
    }

    /**
     * Testa o endpoint interno da API (/api/ibovespa/pos-eleicoes).
     * Verifica o contrato JSON uniforme sem uso de Http::fake().
     */
    public function test_endpoint_api_retorna_contrato_uniforme(): void
    {
        $response = $this->getJson('/api/ibovespa/pos-eleicoes');

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'mercado',
            'origem_dados',
            'aviso',
            'fontes' => ['tse', 'cotacoes'],
            'filtros_aplicados' => ['ano', 'janela'],
            'series' => [
                '*' => [
                    'ano',
                    'eleicao_data',
                    'd0_data',
                    'd0_fechamento',
                    'd30_data',
                    'd30_fechamento',
                    'variacao_percentual',
                    'status_cotacao',
                    'fonte_tse',
                ],
            ],
        ]);

        $dados = $response->json();
        $this->assertEquals('B3 / Ibovespa', $dados['mercado']);
        $this->assertContains($dados['origem_dados'], ['api_externa', 'historico_arquivado_contingencia']);
        $this->assertCount(3, $dados['series']);
    }

    /**
     * Testa a filtragem por ano eleitoral válido (2014, 2018, 2022).
     */
    public function test_filtro_por_ano_valido(): void
    {
        $response = $this->getJson('/api/ibovespa/pos-eleicoes?ano=2018');

        $response->assertStatus(200);
        $dados = $response->json();
        $this->assertCount(1, $dados['series']);
        $this->assertEquals(2018, $dados['series'][0]['ano']);
        $this->assertEquals(2018, $dados['filtros_aplicados']['ano']);
    }

    /**
     * Testa a validação defensiva rejeitando anos não suportados (ex: 1999).
     */
    public function test_rejeita_ano_invalido_com_status_422(): void
    {
        $response = $this->getJson('/api/ibovespa/pos-eleicoes?ano=1999');

        $response->assertStatus(422);
        $response->assertJsonFragment([
            'erro' => 'Parâmetros de consulta inválidos.',
        ]);
    }

    /**
     * Testa a validação e aplicação da janela didática d15.
     */
    public function test_filtro_por_janela_d15_valida(): void
    {
        $response = $this->getJson('/api/ibovespa/pos-eleicoes?janela=d15');

        $response->assertStatus(200);
        $dados = $response->json();
        $this->assertEquals('d15', $dados['filtros_aplicados']['janela']);
        $this->assertEquals('d15', $dados['series'][0]['janela']);
        $this->assertEquals('2014-11-11', $dados['series'][0]['dn_data']);
    }

    /**
     * Testa a validação defensiva rejeitando janelas não suportadas.
     */
    public function test_rejeita_janela_invalida_com_status_422(): void
    {
        $response = $this->getJson('/api/ibovespa/pos-eleicoes?janela=d90');

        $response->assertStatus(422);
        $response->assertJsonFragment([
            'erro' => 'Parâmetros de consulta inválidos.',
        ]);
    }

    /**
     * Testa a resposta de indisponibilidade honesta (HTTP 503) quando nenhum dado está acessível.
     */
    public function test_indisponibilidade_geral_retorna_503_honesto(): void
    {
        // Cria subclasse concreta de serviço simulando indisponibilidade total real
        $servicoIndisponivel = new class extends IbovespaService {
            public function obterCotacoes(?int $anoFiltro = null, string $janela = 'd30'): array
            {
                return [
                    'origem' => 'indisponivel',
                    'series' => [],
                ];
            }
        };

        $this->app->instance(IbovespaService::class, $servicoIndisponivel);

        $response = $this->getJson('/api/ibovespa/pos-eleicoes');

        $response->assertStatus(503);
        $response->assertJson([
            'mercado'      => 'B3 / Ibovespa',
            'origem_dados' => 'indisponivel',
            'series'       => [],
        ]);
    }
}
