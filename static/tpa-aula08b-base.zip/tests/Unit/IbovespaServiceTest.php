<?php

namespace Tests\Unit;

use App\Services\IbovespaService;
use Tests\TestCase;

class IbovespaServiceTest extends TestCase
{
    protected IbovespaService $service;

    protected function setUp(): void
    {
        parent::setUp();
        $this->service = new IbovespaService();
    }

    /**
     * Testa o cálculo de variação percentual com números reais e casos de borda.
     */
    public function test_calcular_variacao_percentual(): void
    {
        // Variação positiva: de 50.000 para 55.000 (+10%)
        $varPositiva = $this->service->calcularVariacao(50000.0, 55000.0);
        $this->assertEquals(10.0, $varPositiva);

        // Variação negativa: de 100.000 para 95.000 (-5%)
        $varNegativa = $this->service->calcularVariacao(100000.0, 95000.0);
        $this->assertEquals(-5.0, $varNegativa);

        // Divisão por zero ou valor inicial não positivo: deve retornar 0.0 defensivamente
        $varZero = $this->service->calcularVariacao(0.0, 50000.0);
        $this->assertEquals(0.0, $varZero);

        $varNegativaInicial = $this->service->calcularVariacao(-10.0, 50000.0);
        $this->assertEquals(0.0, $varNegativaInicial);
    }

    /**
     * Testa enriquecimento de séries com variação percentual tratando valores nulos com rigor.
     */
    public function test_enriquecer_com_variacao_trata_nulos_defensivamente(): void
    {
        $seriesComNulos = [
            [
                'ano'            => 2014,
                'd0_fechamento'  => null,
                'd30_fechamento' => null,
            ],
            [
                'ano'            => 2018,
                'd0_fechamento'  => 85000.0,
                'd30_fechamento' => null, // ausente
            ],
            [
                'ano'            => 2022,
                'd0_fechamento'  => 100000.0,
                'd30_fechamento' => 110000.0,
            ],
        ];

        $enriquecidas = $this->service->enriquecerComVariacao($seriesComNulos);

        $this->assertNull($enriquecidas[0]['variacao_percentual']);
        $this->assertNull($enriquecidas[1]['variacao_percentual']);
        $this->assertEquals(10.0, $enriquecidas[2]['variacao_percentual']);
    }

    /**
     * Testa que o arquivo de contingência local real existe, contém marcos do TSE e cotações nulas.
     * Sem mocks e sem dados inventados.
     */
    public function test_contingencia_local_arquivo_real(): void
    {
        $caminho = storage_path('app/dados/ibovespa_historico.json');
        $this->assertFileExists($caminho);

        $conteudo = json_decode(file_get_contents($caminho), true);
        $this->assertIsArray($conteudo);
        $this->assertEquals('demonstracao_sem_dados_reais', $conteudo['status']);

        $series = $conteudo['series'];
        $this->assertCount(3, $series);

        $anosEsperados = [2014, 2018, 2022];
        foreach ($series as $idx => $item) {
            $this->assertEquals($anosEsperados[$idx], $item['ano']);
            // Valida neutralidade e ausência de preços inventados
            $this->assertNull($item['d0_fechamento']);
            $this->assertNull($item['d30_fechamento']);
            $this->assertNull($item['variacao_percentual']);
            $this->assertNotEmpty($item['fonte_tse']);
        }
    }

    /**
     * Testa se a seleção de janela (d15 vs d30) produz efeito real nas datas dos marcos.
     */
    public function test_janelas_didaticas_produzem_efeito_real(): void
    {
        $dadosD30 = $this->service->obterHistoricoArquivado('d30');
        $this->assertEquals('2014-11-26', $dadosD30[0]['dn_data']);
        $this->assertEquals('d30', $dadosD30[0]['janela']);
        $this->assertStringContainsString('30 dias corridos após D0', $dadosD30[0]['janela_rotulo']);

        $dadosD15 = $this->service->obterHistoricoArquivado('d15');
        $this->assertEquals('2014-11-11', $dadosD15[0]['dn_data']);
        $this->assertEquals('d15', $dadosD15[0]['janela']);
        $this->assertStringContainsString('15 dias corridos após D0', $dadosD15[0]['janela_rotulo']);
    }
}
