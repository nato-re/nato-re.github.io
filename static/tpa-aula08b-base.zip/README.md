# 📊 TPA Aula 08B — Demonstração Completa Executável & Base de Apoio
*Aplicação Didática Base em Laravel para o Ensino Médio Técnico (COTEMIG)*

> **Status da Base: Demonstração Completa e Executável.**  
> Toda a aplicação (serviços backend, controladores, rotas, templates Blade com JavaScript nativo e suíte automatizada de testes com 11 testes e 93 asserções) está totalmente implementada e funcional para execução imediata em container descartável. Os estudantes utilizam esta base para exploração passo a passo, testes de resiliência e modificações guiadas (Exercícios 1 a 8), sem reconstruir a infraestrutura do zero.

Este repositório contém a aplicação didática executável da **Aula 08B** da disciplina de **Técnicas de Programação Avançadas (TPA)**. O objetivo pedagógico central é demonstrar de ponta a ponta o ciclo completo das duas requisições HTTP em uma arquitetura web moderna, utilizando como estudo de caso a consulta de séries temporais do Ibovespa vinculadas a marcos do calendário eleitoral brasileiro (2º turno das eleições gerais de 2014, 2018 e 2022).

---

## 🧭 1. Arquitetura: O Ciclo das Duas Requisições HTTP

A integração é estruturada em dois papéis distintos e complementares:

```
                    ┌──────────────────────────────────────────────┐
                    │  API Externa de Cotações (Yahoo Finance)     │
                    └──────────────────────▲───────────────────────┘
                                           │
                 [Requisição 1: Servidor a Servidor (Http::get)]
                 - Executada em PHP no backend Laravel (IbovespaService)
                 - Timeout defensivo estrito (5s) contra esgotamento de workers
                 - Header User-Agent obrigatório
                 - CORS NÃO se aplica entre servidores
                                           │
                    ┌──────────────────────▼───────────────────────┐
                    │  Aplicação Laravel (Nosso Backend)           │
                    │  Route: GET /api/ibovespa/pos-eleicoes       │
                    │  IbovespaController -> Normalização & Schema  │
                    │  Plano de Contingência Local (JSON TSE)      │
                    └──────────────────────▲───────────────────────┘
                                           │
                 [Requisição 2: Cliente ao Servidor (fetch)]
                 - Executada em JavaScript no navegador (Blade)
                 - Mesma Origem (Same-Origin): sem bloqueio de CORS
                 - Checagem obrigatória de if (!response.ok)
                 - Manipulação segura do DOM (createElement / textContent)
                                           │
                    ┌──────────────────────▼───────────────────────┐
                    │  Navegador do Estudante                      │
                    │  Interface Web, Tabela Segura e Canvas       │
                    └──────────────────────────────────────────────┘
```

### Por que a Requisição 1 é feita pelo Laravel e não pelo Navegador?
1. **CORS (*Cross-Origin Resource Sharing*) é restrição de navegador:** Navegadores bloqueiam requisições assíncronas (`fetch` ou `XMLHttpRequest`) disparadas para origens diferentes da página atual, a menos que o servidor remoto envie cabeçalhos específicos autorizando o acesso. APIs financeiras externas tipicamente não liberam CORS aberto para browsers arbitrários. No entanto, chamadas HTTP servidor-a-servidor (feitas pelo PHP com `Http::get`) trafegam diretamente pela rede e **não passam pelo navegador**, ficando totalmente imunes a bloqueios de CORS.
2. **Encapsulamento e Segurança:** O navegador do usuário final consome exclusivamente a API da própria aplicação, mantendo tokens, credenciais, URLs de infraestrutura e lógica defensiva centralizados no backend.
3. **Resiliência e Proteção do Servidor:** O timeout de 5 segundos (`timeout(5)`) no Laravel impede que instabilidades em serviços externos travem workers do PHP-FPM por até 60 segundos, o que causaria negação de serviço na aplicação local.

---

## ⚖️ 2. Rigor Metodológico e Neutralidade Analítica

- **Fontes Oficiais Verificadas:** As datas das eleições baseiam-se no calendário oficial do **Tribunal Superior Eleitoral (TSE)** para o 2º turno das eleições presidenciais:
  - **2014:** 26/10/2014 — Domingo (Resolução TSE nº 23.390/2013)
  - **2018:** 28/10/2018 — Domingo (Resolução TSE nº 23.555/2017)
  - **2022:** 30/10/2022 — Domingo (Resolução TSE nº 23.674/2021)
- **Definição Explícita de D0:** O marco **D0** é definido rigorosamente como o **primeiro dia útil imediatamente subsequente ao pleito** (segunda-feira pós-2º turno), uma vez que o pleito ocorre no domingo e os mercados financeiros não operam em fins de semana:
  - **2014:** 2º Turno em 26/10/2014 &rarr; Marco Inicial D0 em **27/10/2014** (Segunda-feira).
  - **2018:** 2º Turno em 28/10/2018 &rarr; Marco Inicial D0 em **29/10/2018** (Segunda-feira).
  - **2022:** 2º Turno em 30/10/2022 &rarr; Marco Inicial D0 em **31/10/2022** (Segunda-feira).
- **Marcos Didáticos Dn (D+15 e D+30):** Os marcos **D+15** e **D+30** são **marcos calendários didáticos** que representam exatamente **15 e 30 dias corridos contados a partir de D0** (e não a partir do domingo do pleito). Como são marcos calendários didáticos para análise temporal de séries, **não são anunciados como pregões de bolsa sem verificação na série**:
  - **Janela D+15 (15 dias corridos após D0):**
    - **2014:** 27/10/2014 + 15 dias corridos = **11/11/2014** (Terça-feira).
    - **2018:** 29/10/2018 + 15 dias corridos = **13/11/2018** (Terça-feira).
    - **2022:** 31/10/2022 + 15 dias corridos = **15/11/2022** (Terça-feira — Feriado da Proclamação da República).
  - **Janela D+30 (30 dias corridos após D0):**
    - **2014:** 27/10/2014 + 30 dias corridos = **26/11/2014** (Quarta-feira).
    - **2018:** 29/10/2018 + 30 dias corridos = **28/11/2018** (Quarta-feira).
    - **2022:** 31/10/2022 + 30 dias corridos = **30/11/2022** (Quarta-feira).
- **Não Inferência de Causalidade:** As variações dos mercados financeiros respondem a uma multiplicidade de determinantes macroeconômicos e geopolíticos globais. A concomitância temporal entre datas do calendário eleitoral e flutuações do índice Ibovespa **não constitui relação de causa e efeito**.
- **Neutralidade Absoluta:** O código, as rotas, os dados e a interface **não contêm menção a candidatos, partidos políticos ou vencedores de pleitos**.

---

## 📡 3. Endpoints e Contrato da API

### `GET /api/ibovespa/pos-eleicoes`
Retorna as séries de marcos temporais pós-eleitorais com cotações normalizadas ou status de contingência.

#### Parâmetros de Consulta (Query String)
- `ano` *(opcional, inteiro)*: Filtra por um ano eleitoral específico. Valores permitidos: `2014`, `2018`, `2022`. Caso inválido, retorna HTTP `422 Unprocessable Content`.
- `janela` *(opcional, string)*: Janela temporal de análise. Valores permitidos: `d15` (15 dias corridos após D0) ou `d30` (30 dias corridos após D0 / padrão didático). Caso inválido, retorna HTTP `422 Unprocessable Content`.

#### Resposta de Sucesso da API Externa (HTTP 200 OK)
Exemplo de resposta quando a API externa responde com payload de chart válido. Caso cotações pontuais para os marcos calendários exatos não constem ou não tenham sido verificadas no ambiente local, os fechamentos são tratados defensivamente como `null` (`status_cotacao: "cotacao_indisponivel"`), sem inventar preços de mercado:
```json
{
  "mercado": "B3 / Ibovespa",
  "origem_dados": "api_externa",
  "aviso": "Estrutura didática para análise temporal. Não prova causalidade.",
  "fontes": {
    "tse": "TSE - Calendário Eleitoral Oficial (Resoluções 23.390, 23.555 e 23.674)",
    "cotacoes": "API Externa Yahoo Finance (^BVSP) — sujeita à conectividade de rede"
  },
  "filtros_aplicados": {
    "ano": 2014,
    "janela": "d30"
  },
  "series": [
    {
      "ano": 2014,
      "eleicao_data": "2014-10-26",
      "janela": "d30",
      "janela_rotulo": "D+30 (Marco Calendário Didático: 30 dias corridos após D0)",
      "d0_data": "2014-10-27",
      "d0_fechamento": null,
      "dn_data": "2014-11-26",
      "dn_fechamento": null,
      "d30_data": "2014-11-26",
      "d30_fechamento": null,
      "variacao_percentual": null,
      "status_cotacao": "cotacao_indisponivel",
      "fonte_tse": "TSE Resolução nº 23.390/2013"
    }
  ]
}
```

> **Nota de Rigor Metodológico:** Caso a série externa retorne cotações válidas e verificadas para ambos os marcos (D0 e Dn), o serviço preenche `d0_fechamento`, `dn_fechamento`, calcula a taxa percentual em `variacao_percentual` e assinala `status_cotacao: "serie_disponivel"`. Na ausência de dados verificados para a data exata, os preços são mantidos como `null` para assegurar fidelidade integral aos dados reais.

#### Resposta de Contingência Estrutural (HTTP 200 OK)
Ativada quando a chamada à API externa sofre timeout de rede, erro 4xx/5xx ou payload inválido. Carrega os marcos do TSE a partir de `storage/app/dados/ibovespa_historico.json`, com preços nulos para não inventar cotações:
```json
{
  "mercado": "B3 / Ibovespa",
  "origem_dados": "historico_arquivado_contingencia",
  "aviso": "Estrutura didática para análise temporal. Não prova causalidade.",
  "fontes": {
    "tse": "TSE - Calendário Eleitoral Oficial (Resoluções 23.390, 23.555 e 23.674)",
    "cotacoes": "Demonstração didática de estrutura sem cotações de mercado não verificadas."
  },
  "filtros_aplicados": {
    "ano": null,
    "janela": "d30"
  },
  "series": [
    {
      "ano": 2014,
      "eleicao_data": "2014-10-26",
      "janela": "d30",
      "janela_rotulo": "D+30 (Marco Calendário Didático: 30 dias corridos após D0)",
      "d0_data": "2014-10-27",
      "d0_fechamento": null,
      "dn_data": "2014-11-26",
      "dn_fechamento": null,
      "d30_data": "2014-11-26",
      "d30_fechamento": null,
      "variacao_percentual": null,
      "status_cotacao": "demonstracao_indisponivel",
      "fonte_tse": "TSE Resolução nº 23.390/2013"
    }
  ]
}
```

#### Resposta de Indisponibilidade Geral (HTTP 503 Service Unavailable)
Retornada quando a API externa falha e o arquivo local de contingência também não está disponível:
```json
{
  "mercado": "B3 / Ibovespa",
  "origem_dados": "indisponivel",
  "aviso": "Serviço externo e arquivo local de contingência indisponíveis no momento.",
  "fontes": {
    "tse": "TSE - Calendário Eleitoral Oficial (Resoluções 23.390, 23.555 e 23.674)",
    "cotacoes": "Demonstração indisponível."
  },
  "filtros_aplicados": {
    "ano": null,
    "janela": "d30"
  },
  "series": []
}
```

---

## 🛠️ 4. Pré-requisitos & Instalação

### Opção A: Execução via Docker (Ambiente Isolado Descartável — Recomendado)
Não requer instalação de PHP nem Composer no host.

1. **Clonar ou extrair o projeto em diretório de trabalho:**
   ```bash
   cd /caminho/do/projeto
   ```

2. **Configurar variáveis de ambiente:**
   ```bash
   cp .env.example .env
   ```

3. **Instalar dependências com container descartável:**
   ```bash
   docker run --rm -v $(pwd):/app -w /app composer:2 composer install
   ```

4. **Gerar chave da aplicação (se necessário):**
   ```bash
   docker run --rm -v $(pwd):/app -w /app composer:2 php artisan key:generate
   ```

5. **Executar a suíte de testes automatizados:**
   ```bash
   docker run --rm -v $(pwd):/app -w /app composer:2 php artisan test
   ```

6. **Iniciar o servidor de desenvolvimento:**
   ```bash
   docker run --name tpa_aula08b -p 8000:8000 -v $(pwd):/app -w /app composer:2 php artisan serve --host=0.0.0.0 --port=8000
   ```
   Acesse no navegador: `http://localhost:8000`.

---

### Opção B: Execução com PHP e Composer Locais
- **Pré-requisitos:** PHP 8.2+ (com extensões `curl`, `mbstring`, `openssl`, `pdo_sqlite`), Composer 2+.

1. **Instalação e configuração:**
   ```bash
   cp .env.example .env
   composer install
   php artisan key:generate
   ```

2. **Testes:**
   ```bash
   php artisan test
   ```

3. **Execução:**
   ```bash
   php artisan serve
   ```

---

## 🧪 5. Simulação de Cenários Didáticos (Contingência e Erros)

Para demonstrar a resiliência em sala de aula sem depender de quedas reais de internet:

1. **Cenário 1 — Chamada Externa Bem-Sucedida:**
   Deixe a variável `IBOVESPA_API_URL` padrão no `.env`. A aplicação consome a API externa e normaliza as cotações.

2. **Cenário 2 — Falha Externa com Fallback em JSON Local:**
   Altere no `.env`:
   ```dotenv
   IBOVESPA_API_URL=http://127.0.0.1:9999/indisponivel
   ```
   Execute `php artisan config:clear`. Ao clicar em "Consultar Séries", o Laravel detectará a falha de conexão, acionará a contingência estrutural e exibirá o badge `ORIGEM: CONTINGÊNCIA LOCAL (JSON)`. A tabela exibirá cotações como `— (Indisponível)` e a área de gráfico exibirá honestamente o estado vazio de indisponibilidade.

3. **Cenário 3 — Indisponibilidade Total (HTTP 503):**
   Com a URL externa inválida, renomeie temporariamente o arquivo local:
   ```bash
   mv storage/app/dados/ibovespa_historico.json storage/app/dados/ibovespa_historico.json.bak
   ```
   A API responderá HTTP 503 e o frontend capturará o erro no bloco `.catch()` graças à verificação `if (!response.ok)`.

---

## 🎓 6. Roteiro Pedagógico: Exploração, Teste e Modificação (8 Exercícios Práticos)

Esta base é entregue **completamente funcional** para que o estudante acompanhe a aula executando, diagnosticando e modificando componentes específicos, sem reconstruir a aplicação do zero.

| Exercício | Foco Temático & Conceito | O Que Já Vem Pronto na Base | Atividade Prática do Estudante (Exploração & Modificação) |
| :--- | :--- | :--- | :--- |
| **Ex. 1** | **Requisição 1 & Timeout**<br>`Http::get` no Laravel | `IbovespaService::consultarApiExterna()` com `timeout(5)` e cabeçalhos defensivos. | Inspecionar a chamada; alterar temporariamente o timeout para `0.001` (1ms) para simular queda por lentidão; verificar logs e restaurar para 5s. Validar com `php artisan test --filter=IbovespaServiceTest`. |
| **Ex. 2** | **Tratamento Defensivo & Normalização** | Validação de `$response->successful()`, integridade de `chart.result` e fallback estrutural. | Simular falha de conexão alterando `IBOVESPA_API_URL` no `.env` para uma porta inexistente; comprovar que a aplicação não quebra e aciona a contingência. |
| **Ex. 3** | **Exposição da API JSON**<br>Endpoint no Laravel | `routes/api.php` (`/api/ibovespa/pos-eleicoes`) e `IbovespaController.php` com validação de `ano` e `janela`. | Acessar o endpoint no navegador; testar filtros válidos (`?ano=2018&janela=d15`) e verificar a resposta de erro HTTP 422 para valores inválidos (`?ano=1999`). |
| **Ex. 4** | **Requisição 2 & `fetch()`**<br>A pegadinha do `response.ok` | Função `executarConsulta()` em `ibovespa.blade.php` com `if (!response.ok)` e `response.json()`. | Comentar a linha `if (!response.ok)`; disparar uma requisição para rota com erro para constatar a falha de sintaxe JSON no console; descomentar e observar a captura segura. |
| **Ex. 5** | **Contingência com JSON Local**<br>Marcos TSE | Arquivo `storage/app/dados/ibovespa_historico.json` com marcos oficiais (2014, 2018, 2022) e preços `null`. | Inspecionar a estrutura do JSON local; verificar como a contingência garante que a aplicação responda HTTP 200 com status `historico_arquivado_contingencia`. |
| **Ex. 6** | **Cálculo de Variação com Nulos**<br>Proteção matemática | Método `calcularVariacaoPercentual()` com guarda para `$d0 === null`, `$dn === null` e divisão por zero. | Analisar as cláusulas de guarda; executar a suíte de testes unitários para verificar a cobertura de casos extremos (`null`, `0.0`, valores negativos). |
| **Ex. 7** | **DOM Seguro & Feedback de Loading** | Construção da tabela via `document.createElement()` e `textContent` (proteção contra XSS) e gestão do botão. | Inspecionar a desativação do botão durante o carregamento; personalizar a interface adicionando um novo indicador visual ou coluna na tabela. |
| **Ex. 8** | **Desafio do Gráfico & Cotações Nulas** | Guarda defensiva `temCotacoesReais` e exibição honesta do estado de indisponibilidade no `<canvas>`. | Verificar que com dados de contingência (`null`) a aplicação **NÃO** inventa curvas nem quebra o Canvas, exibindo o estado honesto de "Gráfico Indisponível". Testar a condição de guarda. |

---

### Modo Opcional: Construção do Zero (Desafio TDD)
Para turmas avançadas ou momentos de prática autônoma onde se deseje recriar os métodos:
1. Renomeie o corpo de `IbovespaService::consultarApiExterna()` ou `IbovespaController::index()` para lançar exceção ou retornar array vazio.
2. Execute `php artisan test` e utilize as mensagens de falha para implementar cada requisito passo a passo (abordagem TDD).
