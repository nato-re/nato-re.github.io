<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aula 08B — Integração de APIs & Ciclo das Duas Requisições HTTP | TPA COTEMIG</title>
    <style>
        :root {
            --bg-color: #0f172a;
            --surface-color: #1e293b;
            --surface-hover: #334155;
            --border-color: #475569;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
            --accent-blue: #38bdf8;
            --accent-purple: #c084fc;
            --accent-green: #4ade80;
            --accent-amber: #fbbf24;
            --accent-rose: #f43f5e;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-main);
            line-height: 1.5;
            padding: 24px 16px;
        }
        .container {
            max-width: 1040px;
            margin: 0 auto;
        }
        header {
            margin-bottom: 24px;
            padding-bottom: 16px;
            border-bottom: 1px solid var(--border-color);
        }
        h1 {
            font-size: 1.6rem;
            color: var(--accent-blue);
            margin-bottom: 6px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .subtitle {
            color: var(--text-muted);
            font-size: 0.95rem;
        }

        /* Banner das Duas Requisições */
        .banner-arquitetura {
            background-color: var(--surface-color);
            border-left: 4px solid var(--accent-blue);
            padding: 16px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .banner-arquitetura h2 {
            font-size: 1.05rem;
            color: var(--accent-blue);
            margin-bottom: 10px;
        }
        .grid-requisicoes {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 12px;
        }
        @media (max-width: 720px) {
            .grid-requisicoes { grid-template-columns: 1fr; }
        }
        .card-req {
            background: #0f172a;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 12px;
            font-size: 0.85rem;
        }
        .card-req strong {
            color: var(--accent-purple);
            display: block;
            margin-bottom: 4px;
            font-size: 0.9rem;
        }
        .nota-causalidade {
            background: rgba(251, 191, 36, 0.1);
            border: 1px solid rgba(251, 191, 36, 0.3);
            color: var(--accent-amber);
            padding: 10px 14px;
            border-radius: 6px;
            font-size: 0.85rem;
            margin-bottom: 20px;
        }

        /* Painel de Controles */
        .painel-controles {
            background: var(--surface-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 16px;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
            align-items: flex-end;
        }
        .campo-grupo {
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .campo-grupo label {
            font-size: 0.8rem;
            color: var(--text-muted);
            text-transform: uppercase;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        select, button {
            background: #0f172a;
            color: var(--text-main);
            border: 1px solid var(--border-color);
            padding: 8px 14px;
            border-radius: 6px;
            font-size: 0.9rem;
            outline: none;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        select:focus, button:focus {
            border-color: var(--accent-blue);
        }
        button.btn-primario {
            background-color: #2563eb;
            color: #ffffff;
            border-color: #3b82f6;
            font-weight: 600;
        }
        button.btn-primario:hover:not(:disabled) {
            background-color: #1d4ed8;
        }
        button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Painel de Resultados */
        .painel-resultado {
            background: var(--surface-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 18px;
            margin-bottom: 20px;
        }
        .cabecalho-resultado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 14px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--border-color);
        }
        .badge {
            font-size: 0.75rem;
            padding: 3px 8px;
            border-radius: 9999px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .badge-externa { background: rgba(74, 222, 128, 0.15); color: var(--accent-green); border: 1px solid var(--accent-green); }
        .badge-contingencia { background: rgba(251, 191, 36, 0.15); color: var(--accent-amber); border: 1px solid var(--accent-amber); }
        .badge-indisponivel { background: rgba(244, 63, 94, 0.15); color: var(--accent-rose); border: 1px solid var(--accent-rose); }

        .alerta {
            padding: 12px;
            border-radius: 6px;
            font-size: 0.88rem;
            margin-bottom: 14px;
        }
        .alerta-erro { background: rgba(244, 63, 94, 0.15); border: 1px solid var(--accent-rose); color: #fda4af; }
        .alerta-info { background: rgba(56, 189, 248, 0.1); border: 1px solid var(--accent-blue); color: #bae6fd; }

        /* Tabela */
        .tabela-container {
            overflow-x: auto;
            margin-bottom: 18px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.88rem;
            text-align: left;
        }
        th, td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--border-color);
        }
        th {
            background: #0f172a;
            color: var(--accent-blue);
            font-weight: 600;
        }
        tr:hover td {
            background: var(--surface-hover);
        }

        /* Gráfico / Visualização */
        .area-grafico {
            margin-top: 16px;
            background: #0f172a;
            border: 1px solid var(--border-color);
            border-radius: 6px;
            padding: 16px;
            text-align: center;
        }
        .estado-vazio-grafico {
            padding: 30px 16px;
            color: var(--text-muted);
            font-size: 0.9rem;
        }
        .estado-vazio-grafico strong {
            display: block;
            color: var(--accent-amber);
            margin-bottom: 6px;
        }
        canvas {
            max-width: 100%;
            display: block;
            margin: 0 auto;
        }

        /* Rodapé Didático */
        footer {
            margin-top: 30px;
            padding-top: 16px;
            border-top: 1px solid var(--border-color);
            font-size: 0.8rem;
            color: var(--text-muted);
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 10px;
        }
    </style>
</head>
<body>
<div class="container">

    <header>
        <h1>📊 Séries do Ibovespa em Períodos Pós-Eleitorais</h1>
        <div class="subtitle">Aula 08B — Técnicas de Programação Avançadas (TPA / COTEMIG)</div>
    </header>

    <!-- Mapa Arquitetural das Duas Requisições -->
    <section class="banner-arquitetura">
        <h2>🧭 O Ciclo das Duas Requisições HTTP</h2>
        <div class="grid-requisicoes">
            <div class="card-req">
                <strong>Requisição 1: Servidor-a-Servidor (Laravel &rarr; API Externa)</strong>
                Executada em PHP com <code>Http::withHeaders()->timeout(5)->get(...)</code>.<br>
                <em>CORS não se aplica:</em> Políticas de CORS são implementadas exclusivamente por navegadores para proteger usuários. Requisições entre servidores acontecem diretamente pela rede.
            </div>
            <div class="card-req">
                <strong>Requisição 2: Cliente-ao-Servidor (Navegador &rarr; Laravel API)</strong>
                Executada em JavaScript nativo com <code>fetch('/api/ibovespa/pos-eleicoes')</code>.<br>
                <em>Mesma Origem (Same-Origin):</em> O navegador conversa com nosso próprio backend, consumindo dados normalizados e tratando explicitamente <code>response.ok</code>.
            </div>
        </div>
        <div class="nota-causalidade">
            ⚖️ <strong>Rigor Metodológico & Neutralidade:</strong> As datas das eleições baseiam-se no calendário oficial do Tribunal Superior Eleitoral (TSE: Resoluções 23.390, 23.555 e 23.674). O marco D0 é definido como o 1º dia útil subsequente ao pleito (segunda-feira pós-2º turno). Os marcos D+15 e D+30 são marcos calendários didáticos que representam 15 e 30 dias corridos contados a partir de D0 (não correspondem a pregões sem verificação na série). Cotações de mercado reais não são verificadas no ambiente local e são apresentadas sob estrutura de contingência transparente. Variações históricas refletem conjunturas macroeconômicas complexas; <strong>concomitância temporal não implica causalidade</strong>.
        </div>
    </section>

    <!-- Painel de Filtros e Disparo -->
    <section class="painel-controles">
        <div class="campo-grupo">
            <label for="select-ano">Ano Eleitoral</label>
            <select id="select-ano">
                <option value="">Todos os Anos (2014, 2018, 2022)</option>
                <option value="2014">2014 (2º Turno em 26/10)</option>
                <option value="2018">2018 (2º Turno em 28/10)</option>
                <option value="2022">2022 (2º Turno em 30/10)</option>
            </select>
        </div>
        <div class="campo-grupo">
            <label for="select-janela">Janela Didática</label>
            <select id="select-janela">
                <option value="d30" selected>D+30 (30 dias corridos após D0 — Marco Calendário)</option>
                <option value="d15">D+15 (15 dias corridos após D0 — Marco Calendário)</option>
            </select>
        </div>
        <button id="btn-carregar" class="btn-primario" onclick="executarConsulta()">
            🔄 Consultar Séries
        </button>
    </section>

    <!-- Painel Principal de Dados e Visualização -->
    <section class="painel-resultado">
        <div class="cabecalho-resultado">
            <h3 id="titulo-painel">Status da Integração</h3>
            <div id="badge-container">
                <span id="badge-origem" class="badge">Aguardando consulta</span>
            </div>
        </div>

        <!-- Área de Mensagens / Feedback Seguro -->
        <div id="mensagem-status"></div>

        <!-- Tabela Gerada com createElement e textContent (DOM Seguro) -->
        <div class="tabela-container">
            <table id="tabela-marcos">
                <thead>
                    <tr>
                        <th>Ano</th>
                        <th>2º Turno (TSE)</th>
                        <th>Marco Inicial (D0: 1º dia útil pós-pleito)</th>
                        <th>Fechamento D0</th>
                        <th>Marco Final (Dn: n dias corridos após D0)</th>
                        <th>Fechamento Dn</th>
                        <th>Variação</th>
                        <th>Status Cotação</th>
                        <th>Fonte Oficial</th>
                    </tr>
                </thead>
                <tbody id="tabela-corpo">
                    <tr>
                        <td colspan="9" style="text-align: center; color: var(--text-muted); padding: 20px;">
                            Clique em <strong>"Consultar Séries"</strong> para disparar a Requisição 2 ao Laravel.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Área de Gráfico ou Estado Vazio Honesto -->
        <div class="area-grafico">
            <div id="container-grafico">
                <div class="estado-vazio-grafico">
                    <strong>Visualização Gráfica Reservada</strong>
                    O gráfico de séries temporais só é renderizado quando houver cotações de mercado reais verificadas. Quando os preços são nulos ou a estrutura de contingência estiver ativa, o sistema exibe estado vazio para garantir a fidelidade dos dados.
                </div>
            </div>
            <canvas id="graficoCanvas" width="800" height="240" style="display: none;"></canvas>
        </div>
    </section>

    <footer>
        <div>TPA COTEMIG &bull; Ensino Médio Técnico em Informática</div>
        <div>API interna: <code>/api/ibovespa/pos-eleicoes</code></div>
    </footer>

</div>

<script>
/**
 * Implementação do Frontend Didático (Requisição 2)
 *
 * Princípios demonstrados:
 * 1. Validação obrigatória de if (!response.ok) antes de response.json().
 * 2. Manipulação segura do DOM usando createElement e textContent.
 * 3. Renderização honesta de estados: cotações disponíveis vs dados indisponíveis.
 */
function executarConsulta() {
    const btn = document.getElementById('btn-carregar');
    const selectAno = document.getElementById('select-ano');
    const selectJanela = document.getElementById('select-janela');
    const msgContainer = document.getElementById('mensagem-status');
    const badgeOrigem = document.getElementById('badge-origem');
    const tabelaCorpo = document.getElementById('tabela-corpo');
    const containerGrafico = document.getElementById('container-grafico');
    const canvas = document.getElementById('graficoCanvas');

    // Estado inicial de carregamento
    btn.disabled = true;
    btn.textContent = '⏳ Consultando servidor...';
    msgContainer.textContent = '';
    badgeOrigem.className = 'badge';
    badgeOrigem.textContent = 'Consultando...';

    // Monta URL da Requisição 2 com janela dinâmica
    const janelaValor = selectJanela ? selectJanela.value : 'd30';
    let url = `/api/ibovespa/pos-eleicoes?janela=${encodeURIComponent(janelaValor)}`;
    if (selectAno.value) {
        url += `&ano=${encodeURIComponent(selectAno.value)}`;
    }

    fetch(url)
        .then(response => {
            // A pegadinha do fetch(): respostas 4xx e 500 NÃO rejeitam a Promise!
            if (!response.ok) {
                throw new Error(`Servidor Laravel respondeu com status HTTP ${response.status}`);
            }
            return response.json();
        })
        .then(payload => {
            btn.disabled = false;
            btn.textContent = '🔄 Consultar Séries';

            // Verifica se as séries estão vazias ou indisponíveis
            if (payload.origem_dados === 'indisponivel' || !Array.isArray(payload.series) || payload.series.length === 0) {
                atualizarBadgeOrigem('indisponivel', false);
                renderizarAlerta('alerta-erro', 'Serviço externo e contingência local indisponíveis no momento (HTTP 503).');
                tabelaCorpo.innerHTML = '';
                const tr = document.createElement('tr');
                const td = document.createElement('td');
                td.setAttribute('colspan', '9');
                td.style.textAlign = 'center';
                td.textContent = 'Nenhuma série disponível.';
                tr.appendChild(td);
                tabelaCorpo.appendChild(tr);
                ocultarGrafico('Dados indisponíveis no servidor.');
                return;
            }

            // Checa se há cotações numéricas verificadas na série retornada
            const temCotacoesReais = payload.series.some(item =>
                item.status_cotacao === 'serie_disponivel' &&
                item.d0_fechamento !== null &&
                (item.dn_fechamento !== null || item.d30_fechamento !== null)
            );

            // Atualiza Badge de Proveniência diferenciando se cotações estão disponíveis
            atualizarBadgeOrigem(payload.origem_dados, temCotacoesReais);

            // Alerta e feedback honesto
            if (payload.origem_dados === 'api_externa') {
                if (temCotacoesReais) {
                    renderizarAlerta('alerta-info', '✅ Cotações históricas da API externa verificadas e calculadas com sucesso.');
                } else {
                    renderizarAlerta('alerta-info', 'ℹ️ Resposta HTTP 2xx da API externa recebida com sucesso, mas cotações dos marcos eleitorais não constam ou não foram verificadas no ambiente. Preços tratados defensivamente como nulos.');
                }
            } else if (payload.origem_dados === 'historico_arquivado_contingencia') {
                renderizarAlerta('alerta-info', 'ℹ️ Contingência local ativada: Estrutura arquivada em JSON com marcos didáticos do TSE carregada com sucesso. Cotações de mercado reais não verificadas no ambiente (valores tratados como nulos).');
            }

            // Renderiza Tabela Dinamicamente via DOM seguro
            renderizarTabela(payload.series);

            // Renderiza Gráfico se e somente se houver dados verificados
            if (temCotacoesReais) {
                renderizarGraficoCanvas(payload.series);
            } else {
                ocultarGrafico('Visualização gráfica indisponível: cotações de mercado reais não verificadas no ambiente. Para proteger a fidelidade dos dados, gráficos não são plotados com valores nulos ou inventados.');
            }
        })
        .catch(erro => {
            btn.disabled = false;
            btn.textContent = '🔄 Consultar Séries';
            badgeOrigem.className = 'badge badge-indisponivel';
            badgeOrigem.textContent = 'Falha na Requisição';
            renderizarAlerta('alerta-erro', `Erro ao comunicar com a API Laravel: ${erro.message}`);
            ocultarGrafico('Gráfico indisponível por erro na requisição.');
        });
}

function atualizarBadgeOrigem(origem, temCotacoesReais) {
    const badge = document.getElementById('badge-origem');
    badge.className = 'badge';
    if (origem === 'api_externa') {
        if (temCotacoesReais) {
            badge.classList.add('badge-externa');
            badge.textContent = 'Origem: API Externa (Cotações Verificadas)';
        } else {
            badge.classList.add('badge-contingencia');
            badge.textContent = 'Origem: API Externa (Cotações Indisponíveis)';
        }
    } else if (origem === 'historico_arquivado_contingencia') {
        badge.classList.add('badge-contingencia');
        badge.textContent = 'Origem: Contingência Local (JSON)';
    } else {
        badge.classList.add('badge-indisponivel');
        badge.textContent = 'Origem: Indisponível';
    }
}

function renderizarAlerta(tipo, texto) {
    const container = document.getElementById('mensagem-status');
    container.textContent = '';
    const div = document.createElement('div');
    div.className = `alerta ${tipo}`;
    div.textContent = texto;
    container.appendChild(div);
}

function renderizarTabela(series) {
    const tbody = document.getElementById('tabela-corpo');
    tbody.textContent = '';

    series.forEach(item => {
        const tr = document.createElement('tr');

        // Ano
        const tdAno = document.createElement('td');
        const strongAno = document.createElement('strong');
        strongAno.textContent = item.ano;
        tdAno.appendChild(strongAno);
        tr.appendChild(tdAno);

        // Pleito
        const tdEleicao = document.createElement('td');
        tdEleicao.textContent = item.eleicao_data;
        tr.appendChild(tdEleicao);

        // D+0 Data
        const tdD0Data = document.createElement('td');
        tdD0Data.textContent = item.d0_data;
        tr.appendChild(tdD0Data);

        // D+0 Fechamento
        const tdD0Val = document.createElement('td');
        tdD0Val.textContent = item.d0_fechamento !== null
            ? Number(item.d0_fechamento).toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + ' pts'
            : '— (Indisponível)';
        tr.appendChild(tdD0Val);

        // D+n Data
        const tdDnData = document.createElement('td');
        tdDnData.textContent = item.dn_data || item.d30_data;
        tr.appendChild(tdDnData);

        // D+n Fechamento
        const tdDnVal = document.createElement('td');
        const fechamentoFinal = item.dn_fechamento ?? item.d30_fechamento;
        tdDnVal.textContent = fechamentoFinal !== null
            ? Number(fechamentoFinal).toLocaleString('pt-BR', { minimumFractionDigits: 2 }) + ' pts'
            : '— (Indisponível)';
        tr.appendChild(tdDnVal);

        // Variação %
        const tdVar = document.createElement('td');
        if (item.variacao_percentual !== null && item.variacao_percentual !== undefined) {
            const sinal = item.variacao_percentual > 0 ? '+' : '';
            tdVar.textContent = `${sinal}${item.variacao_percentual}%`;
            tdVar.style.color = item.variacao_percentual >= 0 ? '#4ade80' : '#f43f5e';
            tdVar.style.fontWeight = 'bold';
        } else {
            tdVar.textContent = '—';
            tdVar.style.color = '#94a3b8';
        }
        tr.appendChild(tdVar);

        // Status Cotação
        const tdStatus = document.createElement('td');
        const spanStatus = document.createElement('span');
        spanStatus.className = 'badge';
        if (item.status_cotacao === 'serie_disponivel') {
            spanStatus.classList.add('badge-externa');
            spanStatus.textContent = 'Disponível';
        } else {
            spanStatus.classList.add('badge-contingencia');
            spanStatus.textContent = 'Indisponível';
        }
        tdStatus.appendChild(spanStatus);
        tr.appendChild(tdStatus);

        // Fonte Oficial
        const tdFonte = document.createElement('td');
        tdFonte.style.fontSize = '0.8rem';
        tdFonte.style.color = '#94a3b8';
        tdFonte.textContent = item.fonte_tse || 'TSE Oficial';
        tr.appendChild(tdFonte);

        tbody.appendChild(tr);
    });
}

function ocultarGrafico(mensagem) {
    const containerGrafico = document.getElementById('container-grafico');
    const canvas = document.getElementById('graficoCanvas');
    canvas.style.display = 'none';
    containerGrafico.style.display = 'block';
    containerGrafico.textContent = '';

    const divVazia = document.createElement('div');
    divVazia.className = 'estado-vazio-grafico';
    const strong = document.createElement('strong');
    strong.textContent = 'Visualização Gráfica Indisponível';
    const p = document.createElement('p');
    p.textContent = mensagem;

    divVazia.appendChild(strong);
    divVazia.appendChild(p);
    containerGrafico.appendChild(divVazia);
}

function renderizarGraficoCanvas(series) {
    const containerGrafico = document.getElementById('container-grafico');
    const canvas = document.getElementById('graficoCanvas');
    containerGrafico.style.display = 'none';
    canvas.style.display = 'block';

    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Coleta pontos válidos
    const pontos = [];
    series.forEach(item => {
        const fechamentoFinal = item.dn_fechamento ?? item.d30_fechamento;
        const rotuloFinal = item.janela ? item.janela.toUpperCase() : 'D+n';
        if (item.d0_fechamento !== null) pontos.push({ label: `${item.ano} D+0`, valor: item.d0_fechamento });
        if (fechamentoFinal !== null) pontos.push({ label: `${item.ano} ${rotuloFinal}`, valor: fechamentoFinal });
    });

    if (pontos.length === 0) {
        ocultarGrafico('Nenhum ponto numérico para renderizar.');
        return;
    }

    const minValor = Math.min(...pontos.map(p => p.valor)) * 0.95;
    const maxValor = Math.max(...pontos.map(p => p.valor)) * 1.05;
    const padding = 50;
    const larguraUtil = canvas.width - (padding * 2);
    const alturaUtil = canvas.height - (padding * 2);

    // Desenha eixos
    ctx.strokeStyle = '#475569';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, canvas.height - padding);
    ctx.lineTo(canvas.width - padding, canvas.height - padding);
    ctx.stroke();

    // Desenha linha
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.5;
    ctx.beginPath();

    const passoX = larguraUtil / (pontos.length - 1 || 1);

    pontos.forEach((p, idx) => {
        const x = padding + (idx * passoX);
        const normalizado = (p.valor - minValor) / (maxValor - minValor || 1);
        const y = (canvas.height - padding) - (normalizado * alturaUtil);

        if (idx === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });
    ctx.stroke();

    // Desenha pontos e rótulos
    pontos.forEach((p, idx) => {
        const x = padding + (idx * passoX);
        const normalizado = (p.valor - minValor) / (maxValor - minValor || 1);
        const y = (canvas.height - padding) - (normalizado * alturaUtil);

        ctx.fillStyle = '#c084fc';
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#94a3b8';
        ctx.font = '11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(p.label, x, canvas.height - padding + 16);
        ctx.fillText(Math.round(p.valor).toLocaleString('pt-BR'), x, y - 10);
    });
}
</script>
</body>
</html>
