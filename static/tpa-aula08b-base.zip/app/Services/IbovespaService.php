<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

/**
 * Serviço responsável pela integração com dados do Ibovespa e marcos do calendário eleitoral.
 *
 * Princípios de Resiliência e Metodologia:
 * 1. Requisição 1 (Servidor-a-Servidor via Http::get):
 *    - Timeout defensivo obrigatório de 5s para evitar esgotamento de workers PHP-FPM.
 *    - Header User-Agent explícito.
 *    - Tratamento de falhas de conexão, timeouts e HTTP 4xx/5xx.
 *    - Validação de integridade do payload mesmo sob status HTTP 2xx.
 * 2. Contingência Estrutural:
 *    - Fallback transparente com dados arquivados em storage/app/dados/ibovespa_historico.json.
 *    - O arquivo de contingência contém apenas marcadores de calendário do TSE com cotações nulas,
 *      sem inventar preços de mercado não verificados no ambiente.
 * 3. Rigor Metodológico e Não-Causalidade:
 *    - Marco D0 é definido como o 1º dia útil subsequente ao pleito eleitoral (segunda-feira pós-2º turno).
 *    - Marcos Dn (D+15 ou D+30) representam 15 e 30 dias corridos contados a partir do marco D0 (marcos calendários didáticos).
 *      Não são anunciados como pregões de bolsa sem verificação na série.
 *    - Associação temporal entre eleições e mercado financeiro não constitui relação de causa e efeito.
 *    - Não há menção a candidatos, partidos ou vencedores de pleitos.
 */
class IbovespaService
{
    /**
     * URL padrão do endpoint de séries do Yahoo Finance para o ticker ^BVSP.
     */
    protected string $urlApiExterna = 'https://query1.finance.yahoo.com/v8/finance/chart/%5EBVSP?period1=1414368000&period2=1669852800&interval=1d';

    /**
     * Consulta cotações da API externa com fallback de contingência estrutural.
     *
     * @param int|null $anoFiltro Filtro opcional por ano (2014, 2018, 2022).
     * @param string $janela Janela temporal didática ('d15' ou 'd30').
     * @return array{origem: string, series: array}
     */
    public function obterCotacoes(?int $anoFiltro = null, string $janela = 'd30'): array
    {
        $janela = in_array($janela, ['d15', 'd30'], true) ? $janela : 'd30';
        $origem = 'indisponivel';
        $series = [];

        try {
            $url = config('services.ibovespa.url', $this->urlApiExterna);
            $response = Http::withHeaders([
                'User-Agent' => 'TPA-Cotemig-Aula/1.0',
                'Accept'     => 'application/json',
            ])->timeout(5)->get($url);

            if ($response->successful()) {
                $payload = $response->json() ?? [];
                $resultadoChart = $payload['chart']['result'][0] ?? null;
                $erroChart = $payload['chart']['error'] ?? null;

                // Valida se o payload contém timestamps válidos e não traz erro no corpo
                if (!empty($resultadoChart['timestamp']) && empty($erroChart)) {
                    $origem = 'api_externa';
                    $series = $this->normalizarSeriesExternas($payload, $janela);
                } else {
                    Log::warning('API externa respondeu HTTP 2xx, mas com payload inválido ou erro no chart');
                }
            } else {
                Log::warning('API externa respondeu status HTTP não esperado: ' . $response->status());
            }
        } catch (\Throwable $e) {
            Log::warning('Falha ao consultar API externa de cotações: ' . $e->getMessage());
        }

        // Se a chamada externa falhou ou retornou payload inválido, aciona contingência local
        if ($origem === 'indisponivel') {
            $historico = $this->obterHistoricoArquivado($janela);
            if ($historico !== null) {
                $origem = 'historico_arquivado_contingencia';
                $series = $historico;
            }
        }

        // Enriquece séries com cálculo de variação percentual defensivo
        $series = $this->enriquecerComVariacao($series);

        // Aplica filtro por ano, se solicitado e válido
        if ($anoFiltro !== null && !empty($series)) {
            $series = array_values(array_filter($series, function ($item) use ($anoFiltro) {
                return (int) ($item['ano'] ?? 0) === $anoFiltro;
            }));
        }

        return [
            'origem' => $origem,
            'series' => $series,
        ];
    }

    /**
     * Normaliza a resposta da API externa mapeando os marcos calendários do TSE para a janela escolhida.
     * Cotações ausentes são mantidas como null, sem simular dados inexistentes.
     */
    public function normalizarSeriesExternas(array $dados, string $janela = 'd30'): array
    {
        $marcos = [
            [
                'ano'          => 2014,
                'eleicao_data' => '2014-10-26', // Domingo (2º turno TSE)
                'd0_data'      => '2014-10-27', // Segunda-feira (1º dia útil pós-pleito)
                'd15_data'     => '2014-11-11', // Terça-feira (15 dias corridos após D0)
                'd30_data'     => '2014-11-26', // Quarta-feira (30 dias corridos após D0)
                'fonte_tse'    => 'TSE Resolução nº 23.390/2013',
            ],
            [
                'ano'          => 2018,
                'eleicao_data' => '2018-10-28', // Domingo (2º turno TSE)
                'd0_data'      => '2018-10-29', // Segunda-feira (1º dia útil pós-pleito)
                'd15_data'     => '2018-11-13', // Terça-feira (15 dias corridos após D0)
                'd30_data'     => '2018-11-28', // Quarta-feira (30 dias corridos após D0)
                'fonte_tse'    => 'TSE Resolução nº 23.555/2017',
            ],
            [
                'ano'          => 2022,
                'eleicao_data' => '2022-10-30', // Domingo (2º turno TSE)
                'd0_data'      => '2022-10-31', // Segunda-feira (1º dia útil pós-pleito)
                'd15_data'     => '2022-11-15', // Terça-feira (15 dias corridos após D0 - feriado Proclamação da República)
                'd30_data'     => '2022-11-30', // Quarta-feira (30 dias corridos após D0)
                'fonte_tse'    => 'TSE Resolução nº 23.674/2021',
            ],
        ];

        // Parse defensivo dos timestamps e cotações de fechamento (close)
        $timestamps = $dados['chart']['result'][0]['timestamp'] ?? [];
        $fechamentos = $dados['chart']['result'][0]['indicators']['quote'][0]['close'] ?? [];

        $cotacoesPorData = [];
        if (is_array($timestamps) && is_array($fechamentos)) {
            foreach ($timestamps as $idx => $ts) {
                if (isset($fechamentos[$idx]) && is_numeric($fechamentos[$idx])) {
                    $dataFormatada = gmdate('Y-m-d', (int) $ts);
                    $cotacoesPorData[$dataFormatada] = round((float) $fechamentos[$idx], 2);
                }
            }
        }

        $diasJanela = ($janela === 'd15') ? 15 : 30;

        return array_map(function ($m) use ($cotacoesPorData, $janela, $diasJanela) {
            $dnData = ($janela === 'd15') ? $m['d15_data'] : $m['d30_data'];
            $d0Val = $cotacoesPorData[$m['d0_data']] ?? null;
            $dnVal = $cotacoesPorData[$dnData] ?? null;
            $temCotacoes = ($d0Val !== null && $dnVal !== null);

            return [
                'ano'                 => $m['ano'],
                'eleicao_data'        => $m['eleicao_data'],
                'janela'              => $janela,
                'janela_rotulo'       => "D+{$diasJanela} (Marco Calendário Didático: {$diasJanela} dias corridos após D0)",
                'd0_data'             => $m['d0_data'],
                'd0_fechamento'       => $d0Val,
                'dn_data'             => $dnData,
                'dn_fechamento'       => $dnVal,
                // Chaves de compatibilidade com a Aula 08B
                'd30_data'            => $m['d30_data'],
                'd30_fechamento'      => ($janela === 'd30') ? $dnVal : ($cotacoesPorData[$m['d30_data']] ?? null),
                'variacao_percentual' => null,
                'status_cotacao'      => $temCotacoes ? 'serie_disponivel' : 'cotacao_indisponivel',
                'fonte_tse'           => $m['fonte_tse'],
            ];
        }, $marcos);
    }

    /**
     * Carrega a contingência estrutural a partir do arquivo JSON local.
     */
    public function obterHistoricoArquivado(string $janela = 'd30'): ?array
    {
        $caminho = storage_path('app/dados/ibovespa_historico.json');
        if (!file_exists($caminho)) {
            Log::warning("Arquivo de contingência não encontrado em {$caminho}");
            return null;
        }

        $conteudo = json_decode(file_get_contents($caminho), true);
        $series = $conteudo['series'] ?? null;
        if (!is_array($series)) {
            return null;
        }

        $diasJanela = ($janela === 'd15') ? 15 : 30;
        $mapaD15 = [
            2014 => '2014-11-11', // 15 dias corridos após D0 (2014-10-27)
            2018 => '2018-11-13', // 15 dias corridos após D0 (2018-10-29)
            2022 => '2022-11-15', // 15 dias corridos após D0 (2022-10-31)
        ];

        return array_map(function ($item) use ($janela, $diasJanela, $mapaD15) {
            $dnData = ($janela === 'd15') ? ($item['d15_data'] ?? $mapaD15[$item['ano']] ?? $item['d30_data']) : $item['d30_data'];
            return [
                'ano'                 => $item['ano'],
                'eleicao_data'        => $item['eleicao_data'],
                'janela'              => $janela,
                'janela_rotulo'       => "D+{$diasJanela} (Marco Calendário Didático: {$diasJanela} dias corridos após D0)",
                'd0_data'             => $item['d0_data'],
                'd0_fechamento'       => null,
                'dn_data'             => $dnData,
                'dn_fechamento'       => null,
                'd30_data'            => $item['d30_data'],
                'd30_fechamento'      => null,
                'variacao_percentual' => null,
                'status_cotacao'      => 'demonstracao_indisponivel',
                'fonte_tse'           => $item['fonte_tse'] ?? 'TSE Oficial',
            ];
        }, $series);
    }

    /**
     * Calcula a variação percentual entre valor inicial (D+0) e final (D+n).
     */
    public function calcularVariacao(float $valorInicial, float $valorFinal): float
    {
        if ($valorInicial <= 0.0) {
            return 0.0;
        }

        $variacao = (($valorFinal - $valorInicial) / $valorInicial) * 100;
        return round($variacao, 2);
    }

    /**
     * Enriquece as séries com a taxa percentual de variação, tratando valores nulos com rigor.
     */
    public function enriquecerComVariacao(array $series): array
    {
        return array_map(function ($item) {
            $valFinal = array_key_exists('dn_fechamento', $item)
                ? $item['dn_fechamento']
                : ($item['d30_fechamento'] ?? null);
            $valInicial = $item['d0_fechamento'] ?? null;

            if (!is_null($valInicial) && !is_null($valFinal)) {
                $item['variacao_percentual'] = $this->calcularVariacao(
                    (float) $valInicial,
                    (float) $valFinal
                );
            } else {
                $item['variacao_percentual'] = null;
            }
            return $item;
        }, $series);
    }
}
