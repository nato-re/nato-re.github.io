<?php

namespace App\Http\Controllers;

use App\Services\IbovespaService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
 * Controller responsável por expor a API JSON interna consumida pelo frontend.
 *
 * Papel na Arquitetura:
 * Atua como o servidor da Requisição 2 (Navegador -> Laravel).
 * Encapsula a lógica de backend, garantindo que o navegador não precise acessar
 * diretamente serviços externos e não sofra restrições de CORS.
 */
class IbovespaController extends Controller
{
    public function __construct(
        protected IbovespaService $ibovespaService
    ) {}

    /**
     * Retorna a série de marcos pós-eleitorais do Ibovespa.
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function index(Request $request): JsonResponse
    {
        // Validação defensiva de parâmetros de consulta (query string)
        $validador = Validator::make($request->all(), [
            'ano'    => ['nullable', 'integer', 'in:2014,2018,2022'],
            'janela' => ['nullable', 'string', 'in:d15,d30'],
        ], [
            'ano.in'    => 'O ano informado deve ser 2014, 2018 ou 2022.',
            'janela.in' => 'As janelas didáticas suportadas são d15 (15 dias corridos após D0) e d30 (30 dias corridos após D0).',
        ]);

        if ($validador->fails()) {
            return response()->json([
                'erro'       => 'Parâmetros de consulta inválidos.',
                'mensagens'  => $validador->errors()->all(),
            ], 422);
        }

        $ano = $request->has('ano') ? (int) $request->query('ano') : null;
        $janela = $request->query('janela', 'd30');

        $dados = $this->ibovespaService->obterCotacoes($ano, $janela);

        // Se ambos (API externa e contingência local) estiverem indisponíveis
        if (($dados['origem'] ?? '') === 'indisponivel') {
            return response()->json([
                'mercado'       => 'B3 / Ibovespa',
                'origem_dados'  => 'indisponivel',
                'aviso'         => 'Serviço externo e arquivo local de contingência indisponíveis no momento.',
                'fontes'        => [
                    'tse'      => 'TSE - Calendário Eleitoral Oficial (Resoluções 23.390, 23.555 e 23.674)',
                    'cotacoes' => 'Demonstração indisponível.',
                ],
                'filtros_aplicados' => [
                    'ano'    => $ano,
                    'janela' => $janela,
                ],
                'series'        => [],
            ], 503);
        }

        $fonteCotacoes = match ($dados['origem']) {
            'api_externa' => 'API Externa Yahoo Finance (^BVSP) — sujeita à conectividade de rede',
            'historico_arquivado_contingencia' => 'Demonstração didática de estrutura sem cotações de mercado não verificadas.',
            default => 'Demonstração indisponível.',
        };

        return response()->json([
            'mercado'           => 'B3 / Ibovespa',
            'origem_dados'      => $dados['origem'],
            'aviso'             => 'Estrutura didática para análise temporal. Não prova causalidade.',
            'fontes'            => [
                'tse'      => 'TSE - Calendário Eleitoral Oficial (Resoluções 23.390, 23.555 e 23.674)',
                'cotacoes' => $fonteCotacoes,
            ],
            'filtros_aplicados' => [
                'ano'    => $ano,
                'janela' => $janela,
            ],
            'series'            => $dados['series'],
        ]);
    }
}
