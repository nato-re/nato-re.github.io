<?php

namespace App\Http\Controllers;

use Illuminate\Contracts\View\View;

class WebController extends Controller
{
    /**
     * Renderiza a página principal com a interface de consulta e visualização.
     */
    public function index(): View
    {
        return view('ibovespa');
    }
}
